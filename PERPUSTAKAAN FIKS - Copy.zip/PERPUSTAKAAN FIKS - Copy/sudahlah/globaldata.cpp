#include "globaldata.h"

QVector<Buku> daftarBuku;
